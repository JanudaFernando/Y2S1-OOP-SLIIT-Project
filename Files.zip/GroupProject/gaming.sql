SELECT * FROM gaming.customer;

insert into gaming.customer values(0, 'Januda', 'januda@gmail.com', '07789456123', 'cid001', '01');
insert into gaming.customer values(0, 'Shashi', 'shashi@gmail.com', '07989456456', 'cid002', '02');
insert into gaming.customer values(0, 'Shaini', 'shaini@gmail.com', '07489456789', 'cid003', '03');
insert into gaming.customer values(0, 'Miriyam', 'miriyam@gmail.com', '07712356123', 'cid004', '04');

delete from gaming.customer where id = '14';
